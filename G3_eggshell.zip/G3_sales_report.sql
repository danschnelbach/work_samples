/* Sales report showing the number of house sold by sales rep in the last 30 days */
set linesize 200
COLUMN report_date_col NEW_VALUE report_date
col report_date_col noprint
SELECT TO_CHAR ( SYSDATE ,'DD-Mon-YYYY') AS report_date_col FROM dual;

TTITLE LEFT "Sales Report of last 30 days" SKIP 1
BTITLE LEFT "*** Date: &report_date ***"

column emp_id FORMAT A15
column employee_name FORMAT A20
column licence_num FORMAT A20
column num_of_house_sold FORMAT A20

SELECT s.emp_id, e.f_name || ' ' ||  e.l_name as employee_name, s_rep.licence_no AS licence_num, count(s.sale_id) AS num_of_house_sold
FROM   sale s JOIN sales_representative s_rep ON s.emp_id = s_rep.emp_id
              JOIN employee e ON e.emp_id = s_rep.emp_id
WHERE  signing_date > SYSDATE - 30
GROUP BY s.emp_id , e.f_name,e.l_name, s_rep.licence_no