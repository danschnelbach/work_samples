set linesize 150
COLUMN report_date_col NEW_VALUE report_date
col report_date_col noprint
SELECT TO_CHAR ( SYSDATE ,'DD-Mon-YYYY') AS report_date_col FROM dual;

TTITLE LEFT "Available Homes report" SKIP 1
BTITLE LEFT "*** Date: &report_date ***"

column lot_id heading "Available|lot" JUSTIFY LEFT FORMAT A15 
column subdivision_id heading "Subdivision"
column house_type heading "Style"
column base_price heading "Starting | price" FORMAT $999,999 
column est_complete heading "Completion | date"
column elementary_school heading "Elementary | school" FORMAT A20
column middle_school heading "Middle | school" FORMAT A20
column high_school heading "High | school" FORMAT A20
SELECT lot_id, subdivision_id, cp.est_complete, hs.house_type, hs.base_price,
        sd.elementary_school, sd.middle_school, sd.high_school 
from lot l join construction_progress cp using(lot_id)
    join house_style hs using(style_id)
    join subdivision s using(subdivision_id) 
    join school_district sd using(school_district_id)
where l.status <> 'S'